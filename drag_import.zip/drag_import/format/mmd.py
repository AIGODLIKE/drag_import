import bpy
from bpy.props import (
    BoolProperty,
    StringProperty,

)

from ..prop import drag_import_prop
try:
    try:
        from cats.extern_tools.mmd_tools_local import DictionaryEnum
    except:
        pass
    from mmd_tools.translations import DictionaryEnum
except:
    print('加载mmdtools!')
def _update_types(cls, prop):
    types = cls.types.copy()

    if 'PHYSICS' in types:
        types.add('ARMATURE')
    if 'DISPLAY' in types:
        types.add('ARMATURE')
    if 'MORPHS' in types:
        types.add('ARMATURE')
        types.add('MESH')

    if types != cls.types:
        cls.types = types # trigger update

LOG_LEVEL_ITEMS = [
    ('DEBUG', '4. DEBUG', '', 1),
    ('INFO', '3. INFO', '', 2),
    ('WARNING', '2. WARNING', '', 3),
    ('ERROR', '1. ERROR', '', 4),
]
class drag_import_pmx_prop(bpy.types.PropertyGroup):
    filepath: StringProperty()


    types: bpy.props.EnumProperty(
        name='Types',
        description='Select which parts will be imported',
        options={'ENUM_FLAG'},
        items = [
            ('MESH', 'Mesh', 'Mesh', 1),
            ('ARMATURE', 'Armature', 'Armature', 2),
            ('PHYSICS', 'Physics', 'Rigidbodies and joints (include Armature)', 4),
            ('DISPLAY', 'Display', 'Display frames (include Armature)', 8),
            ('MORPHS', 'Morphs', 'Morphs (include Armature and Mesh)', 16),
        ],
        default={'MESH', 'ARMATURE', 'PHYSICS', 'DISPLAY', 'MORPHS',},
        update=_update_types,
    )
    scale: bpy.props.FloatProperty(
        name='Scale',
        description='Scaling factor for importing the model',
        default=0.08,
    )
    clean_model: bpy.props.BoolProperty(
        name='Clean Model',
        description='Remove unused vertices and duplicated/invalid faces',
        default=True,
    )
    remove_doubles: bpy.props.BoolProperty(
        name='Remove Doubles',
        description='Merge duplicated vertices and faces',
        default=False,
    )
    fix_IK_links: bpy.props.BoolProperty(
        name='Fix IK Links',
        description='Fix IK links to be blender suitable',
        default=False,
    )
    ik_loop_factor: bpy.props.IntProperty(
        name='IK Loop Factor',
        description='Scaling factor of MMD IK loop',
        min=1,
        soft_max=10, max=100,
        default=5,
    )
    apply_bone_fixed_axis: bpy.props.BoolProperty(
        name='Apply Bone Fixed Axis',
        description="Apply bone's fixed axis to be blender suitable",
        default=False,
    )
    rename_bones: bpy.props.BoolProperty(
        name='Rename Bones - L / R Suffix',
        description='Use Blender naming conventions for Left / Right paired bones',
        default=True,
    )
    use_underscore: bpy.props.BoolProperty(
        name="Rename Bones - Use Underscore",
        description='Will not use dot, e.g. if renaming bones, will use _R instead of .R',
        default=False,
    )
    use_mipmap: bpy.props.BoolProperty(
        name='use MIP maps for UV textures',
        description='Specify if mipmaps will be generated',
        default=True,
    )
    try:
        dictionary: bpy.props.EnumProperty(
            name='Rename Bones To English',
            items=DictionaryEnum.get_dictionary_items,
            description='Translate bone names from Japanese to English using selected dictionary',
        )
    except:
        print('开启mmd插件!')
    sph_blend_factor: bpy.props.FloatProperty(
        name='influence of .sph textures',
        description='The diffuse color factor of texture slot for .sph textures',
        default=1.0,
    )
    spa_blend_factor: bpy.props.FloatProperty(
        name='influence of .spa textures',
        description='The diffuse color factor of texture slot for .spa textures',
        default=1.0,
    )
    log_level: bpy.props.EnumProperty(
        name='Log level',
        description='Select log level',
        items=LOG_LEVEL_ITEMS,
        default='INFO',
    )
    save_log: bpy.props.BoolProperty(
        name='Create a log file',
        description='Create a log file',
        default=False,
    )
# class Drag_import_vrma(bpy.types.Operator,drag_import_prop):
#     """Load a vrma file"""
#     bl_idname = 'drag_import.vrma'
#     bl_label = 'Import vrma'
#     bl_options = {'REGISTER', 'PRESET','UNDO'}
#     def execute(self, context):
#         keywords = self.as_keywords(ignore=('filepath','files','pop_menu'))
#         for f in self.files:
#             bpy.ops.import_scene.vrma(filepath=f.name, **keywords)
#         ret = {'FINISHED'}
#         return ret
class drag_import_pmx(bpy.types.Operator, drag_import_pmx_prop,drag_import_prop):
    """Load a pmx file"""
    bl_idname = 'drag_import.pmx'
    bl_label = 'Import pmx'
    bl_options = {'REGISTER', 'PRESET','UNDO'}
    def draw(self, context):
        #包括
        layout = self.layout.box()
        prop = context.scene.drag_import_pmx_prop
        layout.prop(prop, "types")
        layout.prop(prop, "scale")
        layout.prop(prop, "clean_model")
        layout.prop(prop, "remove_doubles")
        layout.prop(prop, "fix_IK_links")
        layout.prop(prop, "ik_loop_factor")
        layout.prop(prop, "apply_bone_fixed_axis")
        layout.prop(prop, "rename_bones")
        layout.prop(prop, "use_underscore")
        layout.prop(prop, "dictionary")

        layout.prop(prop, "use_mipmap")
        layout.prop(prop, "sph_blend_factor")
        layout.prop(prop, "spa_blend_factor")
        layout.prop(prop, "log_level")
        layout.prop(prop, "save_log")


    def invoke(self, context, event):
        # 弹出菜单
        if self.pop_menu:
            return context.window_manager.invoke_props_dialog(self)
        else:
            return self.execute(context)
    def execute(self, context):
        self.set_parameter(context)
        keywords = self.as_keywords(ignore=('filepath','files','pop_menu'))
        for f in self.files:
            bpy.ops.mmd_tools.import_model(filepath=f.name, **keywords)
        ret = {'FINISHED'}
        return ret


    def set_parameter(self, context):
        prop = context.scene.drag_import_pmx_prop
        self.types = prop.types
        self.scale = prop.scale
        self.clean_model = prop.clean_model
        self.remove_doubles = prop.remove_doubles
        self.fix_IK_links = prop.fix_IK_links
        self.ik_loop_factor = prop.ik_loop_factor
        self.apply_bone_fixed_axis = prop.apply_bone_fixed_axis
        self.rename_bones = prop.rename_bones
        self.use_underscore = prop.use_underscore
        self.use_mipmap = prop.use_mipmap
        self.dictionary = prop.dictionary
        self.sph_blend_factor = prop.sph_blend_factor
        self.spa_blend_factor = prop.spa_blend_factor
        self.log_level = prop.log_level
        self.save_log = prop.save_log


def register():
    bpy.utils.register_class(drag_import_pmx_prop)
    bpy.types.Scene.drag_import_pmx_prop = bpy.props.PointerProperty(type=drag_import_pmx_prop)
    bpy.utils.register_class(drag_import_pmx)
    # bpy.utils.register_class(Drag_import_vrma)


def unregister():
    bpy.utils.unregister_class(drag_import_pmx)
    # bpy.utils.unregister_class(Drag_import_vrma)
    del bpy.types.Scene.drag_import_pmx_prop
    bpy.utils.unregister_class(drag_import_pmx_prop)
